package com.example.sociospring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SociospringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SociospringApplication.class, args);
	}

}
